from eddy.core.plugin import AbstractPlugin

class TestPlugin1(AbstractPlugin):
    pass
