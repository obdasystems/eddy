from eddy.core.plugin import AbstractPlugin
# noinspection PyUnresolvedReferences
from eddy.plugins.testplugin2.testmod import testfunc

class TestPlugin2(AbstractPlugin):
    pass
