def testfunc():
    return __file__
